package midiproject;

import javax.swing.JFrame;

public class Main {

    public static void main(String[] args) throws Exception {  
        
        Ikkuna ikkuna = new Ikkuna();
        ikkuna.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ikkuna.setSize(330, 300);
        ikkuna.setVisible(true);
    
    }
}


