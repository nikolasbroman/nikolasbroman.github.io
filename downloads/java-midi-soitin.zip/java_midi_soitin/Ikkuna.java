package midiproject;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class Ikkuna extends JFrame {
    
    private JButton pausePlay;
    private JList savelasteikotLista;
    private JList soittotavatLista;
    private JCheckBox metronomiCheckBox;
    private JList nuottipituusLista;
    private JList nuottienNimetLista;
    private JLabel soittimenNimi;
    private JLabel bpm;
    private static String[] savelasteikoidenNimet = {"Major", "Natural Minor", "Harmonic Minor", "Pentatonic Blues", "Minor Gypsy"};
    private static String[] soittotapojenNimet = {"Soita satunnaista", "Soita nouseva", "Soita laskeva", "Seko satunnainen", "Super satunnainen"};
    private static String[] nuottienPituudet = {"1", "1/2", "1/4", "1/8", "1/16"};
    private static String[] nuottienNimet = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    private JSlider tempoSlider;
    private JSlider soitinSlider;
    public int soittotapaIndeksi;
    private int mikaSavel;
    MidiSoitin soitin;
    
    public Ikkuna() throws Exception {
        super("MIDI soitin");
        setLayout(new FlowLayout());
        
        mikaSavel = 48;
        soitin = new MidiSoitin();
        soitin.savelasteikoksiMajor(mikaSavel, 2);
        soitin.asetaTempo(120, 30000);
        
        savelasteikotLista = new JList(savelasteikoidenNimet);
        savelasteikotLista.setVisibleRowCount(6);
        savelasteikotLista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        savelasteikotEvent saEvent = new savelasteikotEvent();
        savelasteikotLista.addListSelectionListener(saEvent);
        
        soittotavatLista = new JList(soittotapojenNimet);
        soittotavatLista.setVisibleRowCount(6);
        soittotavatLista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        soittotavatEvent stEvent = new soittotavatEvent();
        soittotavatLista.addListSelectionListener(stEvent);
        
        nuottipituusLista = new JList(nuottienPituudet);
        nuottipituusLista.setVisibleRowCount(6);
        nuottipituusLista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        nuotitEvent nEvent = new nuotitEvent();
        nuottipituusLista.addListSelectionListener(nEvent);
        nuottipituusLista.setBounds(120, 10, 50, 150);
        
        nuottienNimetLista = new JList(nuottienNimet);
        nuottienNimetLista.setVisibleRowCount(6);
        nuottienNimetLista.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        nuottienNimetEvent nnEvent = new nuottienNimetEvent();
        nuottienNimetLista.addListSelectionListener(nnEvent);
        
        pausePlay = new JButton("Play");
        pausePlayEvent ppEvent = new pausePlayEvent();
        pausePlay.addActionListener(ppEvent);
        
        tempoSlider = new JSlider(JSlider.HORIZONTAL, 30, 210, 120);
        tempoEvent tEvent = new tempoEvent();
        tempoSlider.addChangeListener(tEvent);
        tempoSlider.setMajorTickSpacing(30);
        tempoSlider.setPaintTicks(true);
        tempoSlider.setPaintLabels(true);
        tempoSlider.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        Font font = new Font("Serif", Font.PLAIN, 14);
        tempoSlider.setFont(font);
        tempoSlider.setPreferredSize(new Dimension(300, 32));
        
        soitinSlider = new JSlider(JSlider.HORIZONTAL, 0, 127, 0);
        soitinEvent sEvent = new soitinEvent();
        soitinSlider.addChangeListener(sEvent);
        soitinSlider.setMajorTickSpacing(127);
        soitinSlider.setPaintTicks(true);
        soitinSlider.setPaintLabels(true);
        soitinSlider.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        soitinSlider.setFont(font);
        soitinSlider.setPreferredSize(new Dimension(300, 38));
        
        soittimenNimi = new JLabel("0: " + soitin.getSoittimenNimi());
        bpm = new JLabel(String.format("%3d", 120));
        
        metronomiCheckBox = new JCheckBox();
        metronomiEvent mEvent = new metronomiEvent();
        metronomiCheckBox.addItemListener(mEvent);
        
        add(new JScrollPane(nuottienNimetLista));
        add(new JScrollPane(savelasteikotLista));
        add(new JScrollPane(soittotavatLista));
        add(new JScrollPane(nuottipituusLista));
        add(pausePlay);
        add(metronomiCheckBox);
        add(bpm);
        add(tempoSlider);
        add(soitinSlider);
        add(soittimenNimi);        
    }
    
    class pausePlayEvent implements ActionListener {
        
        public void actionPerformed(ActionEvent ae) {
            if (soitin.soittoKaynnissa) {
                soitin.lopetaSoitto = true;
            } else {
                if (soittotapaIndeksi == 0) {
                    try {
                        soitin.soitaSatunnaistaTest();
                    } catch (InterruptedException ex) {
                    }
                } else if (soittotapaIndeksi == 1) {
                    try {
                        soitin.soitaNouseva();
                    } catch (InterruptedException ex) {
                    }
                } else if (soittotapaIndeksi == 2) {
                    try {
                        soitin.soitaLaskeva();
                    } catch (InterruptedException ex) {
                    }
                } else if (soittotapaIndeksi == 3) {
                    try {
                        soitin.soitaSekoSatunnainen();
                    } catch (InterruptedException ex) {
                    }
                } else if (soittotapaIndeksi == 4) {
                    try {
                        soitin.soitaSuperSatunnainen();
                    } catch (InterruptedException ex) {
                    }
                }
            }
        }
    }
    
    class savelasteikotEvent implements ListSelectionListener {
        
        public void valueChanged(ListSelectionEvent event) {
            // ilman tätä isAdjustingin tarkistusta ohjelma toteuttaa napinpainalluksen kaksi kertaa
            // hieman kyseenalainen ratkaisu, mutta ei voi mitään
            if (!event.getValueIsAdjusting()) {
                return;
            }
            
            if (savelasteikotLista.getSelectedIndex() == 0) {
                soitin.savelasteikoksiMajor(mikaSavel, 2);
            } else if (savelasteikotLista.getSelectedIndex() == 1) {
                soitin.savelasteikoksiNaturalMinor(mikaSavel, 2);
            } else if (savelasteikotLista.getSelectedIndex() == 2) {
                soitin.savelasteikoksiHarmonicMinor(mikaSavel, 2);
            } else if (savelasteikotLista.getSelectedIndex() == 3) {
                soitin.savelasteikoksiPentatonicBlues(mikaSavel, 2);
            } else if (savelasteikotLista.getSelectedIndex() == 4) {
                soitin.savelasteikoksiMinorGypsy(mikaSavel, 2);
            }
        }
    }
    
    class soittotavatEvent implements ListSelectionListener {
        
        public void valueChanged(ListSelectionEvent event) {
            // ilman tätä isAdjustingin tarkistusta ohjelma toteuttaa napinpainalluksen kaksi kertaa
            // hieman kyseenalainen ratkaisu, mutta ei voi mitään
            if (!event.getValueIsAdjusting()) {
                return;
            }
            soittotapaIndeksi = soittotavatLista.getSelectedIndex();
            if (soittotavatLista.getSelectedIndex() == 0) {
                try {
                    soitin.soitaSatunnaistaTest();
                } catch (InterruptedException ex) {
                }
            } else if (soittotavatLista.getSelectedIndex() == 1) {
                try {
                    soitin.soitaNouseva();
                } catch (InterruptedException ex) {
                }
            } else if (soittotavatLista.getSelectedIndex() == 2) {
                try {
                    soitin.soitaLaskeva();
                } catch (InterruptedException ex) {
                }
            } else if (soittotavatLista.getSelectedIndex() == 3) {
                try {
                    soitin.soitaSekoSatunnainen();
                } catch (InterruptedException ex) {
                }
            } else if (soittotavatLista.getSelectedIndex() == 4) {
                try {
                    soitin.soitaSuperSatunnainen();
                } catch (InterruptedException ex) {
                }
            }
        }
    }
    
    class nuotitEvent implements ListSelectionListener {
        
        public void valueChanged(ListSelectionEvent event) {
            // ilman tätä isAdjustingin tarkistusta ohjelma toteuttaa napinpainalluksen kaksi kertaa
            // hieman kyseenalainen ratkaisu, mutta ei voi mitään
            if (!event.getValueIsAdjusting()) {
                return;
            }
            if (nuottipituusLista.getSelectedIndex() == 0) {
                soitin.asetaTempo(soitin.getBpm(), 240000);
            } else if (nuottipituusLista.getSelectedIndex() == 1) {
                soitin.asetaTempo(soitin.getBpm(), 120000);
            } else if (nuottipituusLista.getSelectedIndex() == 2) {
                soitin.asetaTempo(soitin.getBpm(), 60000);                
            } else if (nuottipituusLista.getSelectedIndex() == 3) {
                soitin.asetaTempo(soitin.getBpm(), 30000);
            } else if (nuottipituusLista.getSelectedIndex() == 4) {
                soitin.asetaTempo(soitin.getBpm(), 15000);
            }          
        }
    }
    
    class nuottienNimetEvent implements ListSelectionListener {
        
        public void valueChanged(ListSelectionEvent event) {
            // ilman tätä isAdjustingin tarkistusta ohjelma toteuttaa napinpainalluksen kaksi kertaa
            // hieman kyseenalainen ratkaisu, mutta ei voi mitään
            if (!event.getValueIsAdjusting()) {
                return;
            }
            if (nuottienNimetLista.getSelectedIndex() == 0) {
                mikaSavel = 48;
                soitin.setJuurinuotti(48);
            } else if (nuottienNimetLista.getSelectedIndex() == 1) {
                mikaSavel = 49;
                soitin.setJuurinuotti(49);
            } else if (nuottienNimetLista.getSelectedIndex() == 2) {
                mikaSavel = 50;
                soitin.setJuurinuotti(50);
            } else if (nuottienNimetLista.getSelectedIndex() == 3) {
                mikaSavel = 51;
                soitin.setJuurinuotti(51);
            } else if (nuottienNimetLista.getSelectedIndex() == 4) {
                mikaSavel = 52;
                soitin.setJuurinuotti(52);
            } else if (nuottienNimetLista.getSelectedIndex() == 5) {
                mikaSavel = 53;
                soitin.setJuurinuotti(53);
            } else if (nuottienNimetLista.getSelectedIndex() == 6) {
                mikaSavel = 54;
                soitin.setJuurinuotti(54);
            } else if (nuottienNimetLista.getSelectedIndex() == 7) {
                mikaSavel = 55;
                soitin.setJuurinuotti(55);
            } else if (nuottienNimetLista.getSelectedIndex() == 8) {
                mikaSavel = 56;
                soitin.setJuurinuotti(56);
            } else if (nuottienNimetLista.getSelectedIndex() == 9) {
                mikaSavel = 57;
                soitin.setJuurinuotti(57);
            } else if (nuottienNimetLista.getSelectedIndex() == 10) {
                mikaSavel = 58;
                soitin.setJuurinuotti(58);
            } else if (nuottienNimetLista.getSelectedIndex() == 11) {
                mikaSavel = 59;
                soitin.setJuurinuotti(59);
            }         
        }
    }
    
    class tempoEvent implements ChangeListener {
        
        public void stateChanged(ChangeEvent e) {
            JSlider source = (JSlider) e.getSource();
            soitin.asetaTempo((int) source.getValue(), soitin.moneskoOsaNuotti);
            bpm.setText(String.format("%3d", soitin.getBpm()));
        }
    }
    
    class soitinEvent implements ChangeListener {
        
        public void stateChanged(ChangeEvent e2) {
            JSlider source = (JSlider) e2.getSource();
            soitin.setSoitin((int) source.getValue());
            soittimenNimi.setText((int) source.getValue() + ": " + soitin.getSoittimenNimi());
        }
    }
    
    class metronomiEvent implements ItemListener {
        
        public void itemStateChanged(ItemEvent ie) {
            if (soitin.metronomiKaynnissa) {
                soitin.metronomiKaynnissa = false;
            } else {
                soitin.metronomiKaynnissa = true;
            }
            
        }
    }
}
