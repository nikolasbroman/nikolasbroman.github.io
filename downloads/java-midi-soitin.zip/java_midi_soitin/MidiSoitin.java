package midiproject;

import java.util.ArrayList;
import java.util.Random;
import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Synthesizer;

public class MidiSoitin {

    private Synthesizer soitin;
    private ArrayList<Integer> savelasteikonNuotit = new ArrayList<Integer>();
    private MidiChannel[] midiKanavat;
    private Instrument soittimet[];
    private Random arpoja;
    private int tempo;
    public int moneskoOsaNuotti;
    private int metronominTempo;
    private int tahti4;
    private int millisekunnit;
    public boolean lopetaSoitto;
    public boolean soittoKaynnissa;
    public boolean metronomiKaynnissa;
    public boolean lopetaMetronomi;
    private boolean synkronisointiPulssi;

    public MidiSoitin() throws MidiUnavailableException {
        soitin = MidiSystem.getSynthesizer();
        soitin.open();
        soittimet = soitin.getDefaultSoundbank().getInstruments();
        soitin.loadInstrument(soittimet[0]); // en ymmärrä numeron merkitystä tässä
        midiKanavat = soitin.getChannels();
        midiKanavat[0].programChange(0); // vaihtaa soitinta
        midiKanavat[1].programChange(115);

        moneskoOsaNuotti = 30000; //60000 = neljäsosanuotti, kun se jaetaan bpm kanssa
        metronominTempo = 60000;
        lopetaSoitto = false;
        soittoKaynnissa = false;
        metronomiKaynnissa = false;
        lopetaMetronomi = false;
        synkronisointiPulssi = false;
        kaynnistaMetronomi();

        arpoja = new Random();
    }

    public void asetaTempo(int bpm, int mikaNuotti) {
        // asettaa sävelten intervallit bpm:n ja moneskoOsaNuotin perusteella.
        // oletuksena on kahdeksasosanuotti, eli 30000
        moneskoOsaNuotti = mikaNuotti;
        tempo = mikaNuotti / bpm;
        metronominTempo = 60000 / bpm;
    }

    public int getBpm() {
        return (moneskoOsaNuotti / tempo);
    }

    private void kaynnistaMetronomi() {
        Runnable runner2 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ
                    while (true) {
                        for (int t = 1; t <= 4; t++) {
                            tahti4 = t;
                            if (metronomiKaynnissa) {
                                midiKanavat[1].noteOn(60, 60); // metronomi
                            }
                            for (int i = 1; i <= metronominTempo; i += 1) {
                                millisekunnit = i;
                                Thread.sleep(1);
                            }
                        }
                    }
                    //--- OHJELMA LOPPUU TÄHÄN                        
                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr2 = new Thread(runner2);
        thr2.start();
    }

    public void soitaSatunnaistaTest() throws InterruptedException {
        Runnable runner1 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ  
                    vaihdaSoittotapa();
                    while (true) {
                        synkkaa();
                        midiKanavat[0].allNotesOff();
                        int nuotti = arpoja.nextInt(savelasteikonNuotit.size());
                        midiKanavat[0].noteOn(savelasteikonNuotit.get(nuotti), 60);
                        for (int i = 0; i < tempo / 2; i += 4) {
                            Thread.sleep(4);
                        }
                        if (lopetaSoitto) {
                            break;
                        }
                    }
                    midiKanavat[0].allNotesOff();
                    soittoKaynnissa = false;
                    //--- OHJELMA LOPPUU TÄHÄN                        
                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr1 = new Thread(runner1);
        thr1.start();
    }

    public void soitaNouseva() throws InterruptedException {
        Runnable runner1 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ
                    vaihdaSoittotapa();
                    int nuotti = 0;
                    while (true) {
                        synkkaa();
                        midiKanavat[0].allNotesOff();
                        midiKanavat[0].noteOn(savelasteikonNuotit.get(nuotti), 60);
                        for (int i = 0; i < tempo / 2; i += 4) {
                            Thread.sleep(4);
                        }

                        nuotti++;
                        if (nuotti >= savelasteikonNuotit.size()) {
                            nuotti = 0;
                        }
                        if (lopetaSoitto) {
                            break;
                        }
                    }
                    midiKanavat[0].allNotesOff();
                    soittoKaynnissa = false;
                    //--- OHJELMA LOPPUU TÄHÄN                        
                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr1 = new Thread(runner1);
        thr1.start();
    }

    public void soitaLaskeva() throws InterruptedException {
        Runnable runner1 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ
                    vaihdaSoittotapa();
                    int nuotti = savelasteikonNuotit.size() - 1;
                    while (true) {
                        synkkaa();
                        midiKanavat[0].allNotesOff();
                        midiKanavat[0].noteOn(savelasteikonNuotit.get(nuotti), 60);
                        for (int i = 0; i < tempo / 2; i += 4) {
                            Thread.sleep(4);
                        }

                        nuotti--;
                        if (nuotti < 0) {
                            nuotti = savelasteikonNuotit.size() - 1;
                        }
                        if (lopetaSoitto) {
                            break;
                        }
                    }
                    midiKanavat[0].allNotesOff();
                    soittoKaynnissa = false;
                    //--- OHJELMA LOPPUU TÄHÄN                        
                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr1 = new Thread(runner1);
        thr1.start();
    }

    public void soitaSekoSatunnainen() throws InterruptedException {
        Runnable runner1 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ  
                    vaihdaSoittotapa();
                    int nuotinPituus = tempo / 2;
                    int todennakoisyysVaihdolle = 1;
                    int nuotti = arpoja.nextInt(savelasteikonNuotit.size());

                    while (true) {
                        if (arpoja.nextInt(todennakoisyysVaihdolle) == 0) {
                            int apu = arpoja.nextInt(3);
                            if (apu == 0) {
                                nuotinPituus = tempo / 3;
                                todennakoisyysVaihdolle = 4;
                            } else if (apu == 1) {
                                nuotinPituus = tempo / 2;
                                todennakoisyysVaihdolle = 4;
                            } else if (apu == 2) {
                                nuotinPituus = tempo / 1;
                                todennakoisyysVaihdolle = 2;
                            }
                        }
                        midiKanavat[0].allNotesOff();
                        int joku = arpoja.nextInt(8) + 1;
                        if (arpoja.nextInt(2) == 0) {
                            nuotti = nuotti - joku;
                            if (nuotti < 0) {
                                nuotti = 0 - nuotti;
                            }
                        } else {
                            nuotti = nuotti + joku;
                            if (nuotti >= savelasteikonNuotit.size()) {
                                nuotti = savelasteikonNuotit.size() - joku - 1;
                            }
                        }
                        midiKanavat[0].noteOn(savelasteikonNuotit.get(nuotti), 60);
                        for (int i = 0; i < nuotinPituus; i += 4) {
                            Thread.sleep(4);
                        }
                        if (lopetaSoitto) {
                            break;
                        }
                    }
                    midiKanavat[0].allNotesOff();
                    soittoKaynnissa = false;
                    //--- OHJELMA LOPPUU TÄHÄN                        
                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr1 = new Thread(runner1);
        thr1.start();
    }

    public void soitaSuperSatunnainen() throws InterruptedException {
        Runnable runner1 = new Runnable() {
            public void run() {
                try {
                    //--- OHJELMA ALKAA TÄSTÄ  
                    vaihdaSoittotapa();
                    int nuotinPituus = tempo / 2;
                    int todennakoisyysVaihdolle = 1;
                    int nuotti = arpoja.nextInt(savelasteikonNuotit.size());
                    int indeksi = 1;
                    while (true) {
                        synkkaa();
                        midiKanavat[0].allNotesOff();
                        int joku = arpoja.nextInt(4) + 1;
                        if (arpoja.nextInt(24) == 0) {
                            if (arpoja.nextInt(2) == 0) {
                                indeksi = savelasteikonNuotit.indexOf(savelasteikonNuotit.get(nuotti) + 12);
                                if (indeksi != -1) {
                                    nuotti = indeksi;
                                } else {
                                    nuotti = savelasteikonNuotit.indexOf(savelasteikonNuotit.get(nuotti) - 12);
                                }
                            } else {
                                indeksi = savelasteikonNuotit.indexOf(savelasteikonNuotit.get(nuotti) - 12);
                                if (indeksi != -1) {
                                    nuotti = indeksi;
                                } else {
                                    nuotti = savelasteikonNuotit.indexOf(savelasteikonNuotit.get(nuotti) + 12);
                                }
                            }
                        } else if (arpoja.nextInt(2) == 0) {
                            nuotti = nuotti - joku;
                            if (nuotti < 0) {
                                nuotti = 0 - nuotti;
                            }
                        } else {
                            nuotti = nuotti + joku;
                            if (nuotti >= savelasteikonNuotit.size()) {
                                nuotti = savelasteikonNuotit.size() - joku - 1;
                            }
                        }
                        midiKanavat[0].noteOn(savelasteikonNuotit.get(nuotti), 60);
                        for (int i = 0; i < tempo / 2; i += 4) {
                            Thread.sleep(4);
                        }
                        if (lopetaSoitto) {
                            break;
                        }
                    }
                    midiKanavat[0].allNotesOff();
                    soittoKaynnissa = false;
                    //--- OHJELMA LOPPUU TÄHÄN                        

                } catch (InterruptedException iex) {
                }
            }
        };
        Thread thr1 = new Thread(runner1);
        thr1.start();
    }

    private void vaihdaSoittotapa() throws InterruptedException {
        if (soittoKaynnissa) {
            lopetaSoitto = true;
            while (true) {
                Thread.sleep(0); // ilman tätä ohjelma ei tajua, että soittoKaynnissa on false !?
                if (!soittoKaynnissa) {
                    break;
                }
            }
        }
        synkkaa();
        soittoKaynnissa = true;
        lopetaSoitto = false;
    }

    private void synkkaa() throws InterruptedException {
        if (moneskoOsaNuotti == 240000) {
            Thread.sleep(0);
            while (true) {
                Thread.sleep(0);
                if (tahti4 == 1 && millisekunnit == 1) {
                    break;
                }
            }
        } else if (moneskoOsaNuotti == 120000) {
            Thread.sleep(0);
            while (true) {
                Thread.sleep(0);
                if (tahti4 == 1 && millisekunnit == 1 || tahti4 == 3 && millisekunnit == 1) {
                    break;
                }
            }
        } else if (moneskoOsaNuotti == 60000) {
            Thread.sleep(0);
            while (millisekunnit != 1) {
                Thread.sleep(0);
            }
        } else if (moneskoOsaNuotti == 30000) {
            Thread.sleep(0);
            while (true) {
                int apu = metronominTempo / 2;
                apu = apu * 2;
                Thread.sleep(0);
                if (millisekunnit == 1 || millisekunnit * 2 == apu) {
                    break;
                }
            }
        } else if (moneskoOsaNuotti == 15000) {
            Thread.sleep(0);
            while (true) {
                int apu = metronominTempo / 4;
                apu = apu * 4;
                Thread.sleep(0);
                if (millisekunnit == 1 || millisekunnit * 2 == apu ||  millisekunnit * 4 == apu || millisekunnit + (millisekunnit / 3) == apu) {
                    break;
                }
            }
        }
    }

    public void savelasteikoksiMajor(int mikaSavel, int montakoOktaavia) {
        savelasteikonNuotit.clear();
        int apu = 0;
        for (int i = mikaSavel; i <= mikaSavel + 12 * montakoOktaavia; i += 2) {
            if (i > 127) {
                break;
            }
            savelasteikonNuotit.add(i);
            apu++;
            if (apu == 3) {
                i -= 1;
            } else if (apu == 7) {
                i -= 1;
                apu = 0;
            }

        }
    }

    public void savelasteikoksiNaturalMinor(int mikaSavel, int montakoOktaavia) {
        savelasteikonNuotit.clear();
        int apu = 0;
        for (int i = mikaSavel; i <= mikaSavel + 12 * montakoOktaavia; i += 2) {
            if (i > 127) {
                break;
            }
            savelasteikonNuotit.add(i);
            apu++;
            if (apu == 2) {
                i -= 1;
            } else if (apu == 5) {
                i -= 1;
                apu = -2;
            }

        }
    }

    public void savelasteikoksiHarmonicMinor(int mikaSavel, int montakoOktaavia) {
        savelasteikonNuotit.clear();
        int apu = 0;
        for (int i = mikaSavel; i <= mikaSavel + 12 * montakoOktaavia; i += 2) {
            if (i > 127) {
                break;
            }
            savelasteikonNuotit.add(i);
            apu++;
            if (apu == 2) {
                i -= 1;
            } else if (apu == 5) {
                i -= 1;
            } else if (apu == 6) {
                i += 1;
            } else if (apu == 7) {
                i -= 1;
                apu = 0;
            }

        }
    }

    public void savelasteikoksiPentatonicBlues(int mikaSavel, int montakoOktaavia) {
        savelasteikonNuotit.clear();
        int apu = 0;
        for (int i = mikaSavel; i <= mikaSavel + 12 * montakoOktaavia; i += 2) {
            if (i > 127) {
                break;
            }
            savelasteikonNuotit.add(i);
            apu++;
            if (apu == 1 || apu == 5) {
                i += 1;
            } else if (apu == 3 || apu == 4) {
                i -= 1;
            } else if (apu == 6) {
                apu = 0;
            }

        }
    }

    public void savelasteikoksiMinorGypsy(int mikaSavel, int montakoOktaavia) {
        savelasteikonNuotit.clear();
        int apu = 0;
        for (int i = mikaSavel; i <= mikaSavel + 12 * montakoOktaavia; i += 1) {
            if (i > 127) {
                break;
            }
            savelasteikonNuotit.add(i);
            apu++;
            if (apu == 2 || apu == 6) {
                i += 2;
            } else if (apu == 4) {
                i += 1;
            } else if (apu == 7) {
                apu = 0;
            }

        }
    }

    public void setJuurinuotti(int mikaSavel) {
        int erotus = mikaSavel - savelasteikonNuotit.get(0);
        for (int i = 0; i < savelasteikonNuotit.size(); i++) {
            savelasteikonNuotit.set(i, savelasteikonNuotit.get(i) + erotus);
        }
    }

    public void setSoitin(int soitinNumero) {
        midiKanavat[0].programChange(soitinNumero);
    }

    public String getSoittimenNimi() {
        return soittimet[midiKanavat[0].getProgram()].getName();
    }
}
